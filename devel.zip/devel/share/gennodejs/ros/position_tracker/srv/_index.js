
"use strict";

let GetPosition = require('./GetPosition.js')

module.exports = {
  GetPosition: GetPosition,
};
